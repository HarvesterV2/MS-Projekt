#Dane
Market_1 <- c(30.9, 29.9, 33.4, 31.5, 32.8, 33.5, 21.3, 27, 37.3, 24.5,
              +              36.5, 38.5, 35.5, 27.8, 29, 34.5, 38.4, 24.6, 33.4, 32.8,
              +              34.8, 32.2, 33.8, 29.1, 31.5, 28.1, 37.4, 36.2, 31.9, 30.4,
              +              29.6, 24.8, 30.9, 29, 22.2, 30.7, 30.9, 34.7, 33.4, 33.2,
              +              32.5, 34.9, 31.5, 34.5, 28, 34, 34.5, 36.6, 36.6, 31.2,
              +              35.7, 29.8)
Market_2 <- c(37.7, 34.6, 28.9, 37.8, 39.4, 34.3, 39.3, 33.2,
              +               34.7, 33, 29.9, 37.8, 34.1, 29.7, 36, 29.9, 33.8, 34.1,
              +               35.5, 37, 32.9, 35.7, 34, 29, 33.3, 33.7, 30.8, 34.7,
              +               33.3, 31, 29.6, 36.5, 32.5, 40.6, 27.8, 41.5, 31.8, 33,
              +               31.3, 33.9, 34.8, 43.5, 31.9, 32.2, 34, 30.6, 30.3)
#Mediana to miara statystyczna wskazujaca srodek uporzadkowanego zbioru danych, dzieli ona dane na dwie rowne czesci 
#Mediana w wykresie nie jest wykorzystywana, bo jest ona robiona juz dzieki funkcji boxplot()
Mediana_Market_1 <- median(Market_1)
Mediana_Market_2 <- median(Market_2)
#Wartosc oczekiwana
Wartosc_Oczekiwana_Market_1 <- mean(Market_1)
Wartosc_Oczekiwana_Market_2 <- mean(Market_2)
#Wykres mediana i kwartyle
boxplot(Market_1, Market_2, names=c("Market_1", "Market_2"),
        main="Wykres 1: Mediana i kwartyle",
        ylab="Wydatki [zl]")
#Wykres wartosc oczekiwana i odchylenie standardowe
Srednie <- c(mean(Market_1), mean(Market_2))
Odchylenie_Stand <-c(sd(Market_1), sd(Market_2))
barplot(Srednie, main="Wykres 2: Srednia i odchylenie standardowe")

